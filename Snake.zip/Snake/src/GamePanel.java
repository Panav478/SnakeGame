import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {
    public static final int UNIT_SIZE = 20;
    public static final int GAME_UNITS = (GameWindow.WIDTH * GameWindow.HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    public static final int DELAY = 100;

    public final int[] snakeX = new int[GAME_UNITS];
    public final int[] snakeY = new int[GAME_UNITS];
    public int snakeLength = 1;
    public int foodX;
    public int foodY;
    public Direction direction = Direction.RIGHT;
    public boolean isRunning = false;
    public Timer timer;

    public GamePanel() {
        setFocusable(true);
        setPreferredSize(new Dimension(GameWindow.WIDTH, GameWindow.HEIGHT));
        setBackground(Color.BLACK);
        addKeyListener(new SnakeKeyListener());

        startGame();
    }

    public void startGame() {
        snakeX[0] = GameWindow.WIDTH / 2;
        snakeY[0] = GameWindow.HEIGHT / 2;
        generateFood();

        isRunning = true;
        timer = new Timer(DELAY, this);
        timer.start();
    }

    public void generateFood() {
        Random random = new Random();
        foodX = random.nextInt(GameWindow.WIDTH / UNIT_SIZE) * UNIT_SIZE;
        foodY = random.nextInt(GameWindow.HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void move() {
        for (int i = snakeLength; i > 0; i--) {
            snakeX[i] = snakeX[i - 1];
            snakeY[i] = snakeY[i - 1];
        }

        switch (direction) {
            case UP:
                snakeY[0] -= UNIT_SIZE;
                break;
            case DOWN:
                snakeY[0] += UNIT_SIZE;
                break;
            case LEFT:
                snakeX[0] -= UNIT_SIZE;
                break;
            case RIGHT:
                snakeX[0] += UNIT_SIZE;
                break;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the snake
        for (int i = 0; i < snakeLength; i++) {
            if (i == 0) {
                g.setColor(Color.GREEN); // Head color
            } else {
                g.setColor(Color.GREEN.darker()); // Body color
            }
            g.fillRect(snakeX[i], snakeY[i], UNIT_SIZE, UNIT_SIZE);
        }

        // Draw the food
        g.setColor(Color.RED);
        g.fillOval(foodX, foodY, UNIT_SIZE, UNIT_SIZE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (isRunning) {
            move();
            checkCollision();
            repaint();
        }
    }

    public class SnakeKeyListener extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_UP && direction != Direction.DOWN) {
                direction = Direction.UP;
            } else if (key == KeyEvent.VK_DOWN && direction != Direction.UP) {
                direction = Direction.DOWN;
            } else if (key == KeyEvent.VK_LEFT && direction != Direction.RIGHT) {
                direction = Direction.LEFT;
            } else if (key == KeyEvent.VK_RIGHT && direction != Direction.LEFT) {
                direction = Direction.RIGHT;
            }
        }
    }

    public void checkCollision() {
        // Check if snake collides with itself
        for (int i = snakeLength - 1; i > 0; i--) {
            if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
                isRunning = false;
                restartGame();
            }
        }

        // Check if snake collides with the boundaries of the window
        if (snakeX[0] < 0 || snakeX[0] >= GameWindow.WIDTH || snakeY[0] < 0 || snakeY[0] >= GameWindow.HEIGHT) {
            isRunning = false;
            restartGame();
        }

        // Check if snake eats the food
        if (snakeX[0] == foodX && snakeY[0] == foodY) {
            snakeLength++;
            generateFood();
        }
    }

    public void restartGame() {
        snakeLength = 1;
        direction = Direction.RIGHT;
        snakeX[0] = GameWindow.WIDTH / 2;
        snakeY[0] = GameWindow.HEIGHT / 2;
        generateFood();

        isRunning = true;
        timer.restart();
    }



    public enum Direction {
        UP, DOWN, LEFT, RIGHT
    }
}
