import javax.swing.*;
import java.awt.*;

public class GameWindow extends JFrame {
    public static final int WIDTH = 400;
    public static final int HEIGHT = 400;

    public GameWindow() {
        setTitle("Snake Game");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);

        add(new GamePanel());
    }
}
